// Placeholder cho xử lý người dùng
module.exports = {
  getUser: (id) => ({ id, name: "User" + id })
}